$(document).ready(function() {

  $("#resetconfirm").confirm();


})
